import pandas as pd
import numpy as np
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import LocalOutlierFactor

import warnings
warnings.filterwarnings("ignore", category=RuntimeWarning) 


def Create_TRAIN_TEST_data(LF_dat, list_TaxID_TP, test=False):
    """
    Annotate LineageFilter data (True Positive or False Positive genus)

    :param LF_dat: a pandas dataframe, corresponding to LF-formated data (see getLFdat function)
    :type LF_dat: pandas.core.frame.DataFrame
    :param list_TaxID_TP: a list containing the NCBI taxonomical ID of taxa present in sample (genus level)
    :type list_TaxID_TP: list
    
    :return: a dataframe corresponding to LF-formated data with class column for random forest training
    :rtype: pandas.core.frame.DataFrame
    """
    
    LFdat_annot = LF_dat.copy(deep=True)  ;  LFdat_annot.loc[LFdat_annot['TaxID__genus']=='', 'TaxID__genus'] = 0
    LFdat_annot['TaxID__genus'] = LFdat_annot['TaxID__genus'].fillna(0).astype(int)
    LFdat_annot['Class'] = LFdat_annot['TaxID__genus'].isin(list_TaxID_TP).astype(int)
    #Add missing taxa (non-detected) for test data
    if test:
        missing_taxa = set(list_TaxID_TP)-set(LFdat_annot['TaxID__genus'].fillna(0).astype(int))
        for taxID in missing_taxa:
            LFdat_annot = pd.concat([LFdat_annot,pd.DataFrame({'TaxID__genus':[taxID],'Class':[1]})])
    return(LFdat_annot)

def Create_RFmodel(TRAIN_data, path_saveRF, QSPE_colname='# spePEPS'):
    """
    Create Random Forest model from train data and save it

    :param TRAIN_data: a pandas dataframe, corresponding to LF train data (see Create_TRAIN_TEST_data function)
    :type TRAIN_data: pandas.core.frame.DataFrame
    :param path_saveRF: path where to save random forest model
    :type path_saveRF: str
    :param QSPE_colname: name of the specific quantification colname, default # spePEPS (Unipept)
    :type QSPE_colname: str
    
    :return: path to the random forest model
    :rtype: str
    """
    
    #Filter training data by removing useless/bad training datas
    TRAIN_size = len(TRAIN_data)
    TRAIN_data = TRAIN_data[~((TRAIN_data['Class']==1)&(TRAIN_data['LOGneg_best_expect__0__genus']==0))].dropna()
    TRAIN_data = TRAIN_data[TRAIN_data['Missed_Added']==0]
    print('Pruning '+str(TRAIN_size-len(TRAIN_data))+' bad training observations')
    
    relevant_features = [i for i in TRAIN_data.columns if ('Name' not in i)&('#' not in i)&('Class' not in i)&('Missed_Added' not in i)&
                         ('TaxID' not in i)&(i not in ['phylum', 'class', 'order', 'family', 'genus'])&('sample_ID' not in i)&
                         ('sig_cross' not in i)&('taxa_val' not in i)&('nonSPE_val' not in i)&('cross' not in i)&('sd1' not in i)&
                         ('sd2' not in i)&('sigma_noise' not in i)&('mu1' not in i)&('mu2' not in i)&('maxSPE' not in i)&('acc_spe_evolve' not in i)]

    X_train = TRAIN_data[relevant_features].copy(deep=True)  ;  y_train = TRAIN_data['Class']
    
    #Define model hyperparameters
    best_max_depth = None  ;  best_min_samples_split = 3  ;  best_max_leaf_nodes = sum(y_train)*2  ;  best_min_samples_leaf = 1
    best_max_samples = sum(y_train)*2  ;  best_n_estimators = int(np.sqrt(sum(y_train))*len(relevant_features)*1.25)
    best_max_features = int(np.ceil(len(relevant_features)*0.7))
    
    #If data too much noised -> Change training strategy to take it into account
    fraction_noise = sum(y_train)/sum([1 if i==0 else 0 for i in y_train])
    if np.round(fraction_noise,2)<=1e-2:
        #Cleaning/Pruning training data (avoid wrong overfitting for noised data)
        print("Data too much noised, changing training' strategy")  ;  TRAIN_size = len(TRAIN_data)
        TRAIN_data = TRAIN_data[~((TRAIN_data['Class']==0)&(TRAIN_data['LOGneg_best_expect__1__genus']<=0))]
        thr_SPE = int(np.ceil(np.quantile(TRAIN_data[(TRAIN_data['Class']==0)][QSPE_colname+'__genus'], 0.95)))
        TRAIN_data = TRAIN_data[~((TRAIN_data['Class']==1)&(TRAIN_data[QSPE_colname+'__genus']<thr_SPE))]
        print('\tPruning '+str(TRAIN_size-len(TRAIN_data))+' training observations')
        
        #Adjusting model hyperparameters & features
        ##specific quantification isn't relevant anymore -> Bimodal gaussian values will be used to filter outliers predictions
        relevant_features = [i for i in relevant_features if ('diff_acc_spe' not in i)&('SPE' not in i)]
        best_max_features = len(relevant_features)
        X_train = TRAIN_data[relevant_features].copy(deep=True)  ;  y_train = TRAIN_data['Class']
   
    RF = RandomForestClassifier(max_depth=best_max_depth, min_samples_split=best_min_samples_split, max_leaf_nodes=best_max_leaf_nodes,
                                min_samples_leaf=best_min_samples_leaf, max_samples=best_max_samples, n_estimators=best_n_estimators,
                                criterion='entropy', max_features=best_max_features, verbose=0, random_state=42, class_weight='balanced_subsample')
    RF.fit(X_train, y_train)  ;  pickle.dump(RF, open(path_saveRF, 'wb'))
    print("Model save at : "+path_saveRF)
    return(None)

def OutlierFiltering(TEST_data_pred, features_iso=['pred', 'BimodalVAL__family', 'BimodalVAL__genus'],
                    thr_predUP1=0.45, thr_predDOWN1=0.15, thr_predUP2=0.40, thr_predDOWN2=0.15, thr_evol_corr=1e-3,
                     thr_ratio_diff_INV=0.25, thr_prun=0.8, factor_pred_decrease=4):
    """
    Filter observations close to prediction cut-off (0.5) by using LocalOutlierFactor

    :param TEST_data_pred: a pandas dataframe, corresponding to LF test data (see predict_class function)
    :type TEST_data_pred: pandas.core.frame.DataFrame
    :param features_iso: features used to compute outlier score (see sklearn.neighbors.LocalOutlierFactor)
    :type features_iso: list
    :param thr_predUP1: the upper limit of probability considered close to prediction cut-off (0.5), for first filtering step (see after)
    :type thr_predUP1: float
    :param thr_predDOWN1: the lower limit of probability considered close to prediction cut-off (0.5), for first filtering step (see after)
    :type thr_predDOWN1: float
    :param thr_predUP2: the upper limit of probability considered close to prediction cut-off (0.5), for second filtering step (see after)
    :type thr_predUP2: float
    :param thr_predDOWN2: the lower limit of probability considered close to prediction cut-off (0.5), for second filtering step (see after)
    :type thr_predDOWN2: float
    :param thr_evol_corr: the minimum increase in correlation (see after) for first filtering step
    :type thr_evol_corr: float
    :param thr_ratio_diff_INV: used in second filtering step, deviation threshold of the outlier score (see after)
    :type thr_ratio_diff_INV: float
    :param thr_prun: used in second filtering step, pruning threshold to determine if outlier scores should be recalculated (see after)
    :type thr_prun: float
    :param factor_pred_decrease: factor to decrease probabilities of identified outliers (see after)
    :type factor_pred_decrease: int
    
    :return: LF test data with corrected probabilities values
    :rtype: pandas.core.frame.DataFrame
    """
    
    #First filtering for very noised prediction (correlation between prediction and Bimodal's value <=0.75)
    count_prun = 0.5  ;  loop_IN = True  ;  dex = 0  ;  index_prun = []

    ##Get relevant data and fit the LocalOutlierFactor model
    subTEST = TEST_data_pred[(TEST_data_pred['pred']>=thr_predDOWN1)&(TEST_data_pred['pred']<=thr_predUP1)].copy(deep=True).fillna(1)
    clf = LocalOutlierFactor(n_neighbors=2, p=1).fit(-np.log(subTEST[features_iso]))
    subTEST['scoreOUT'] = np.abs(1-np.abs(clf.negative_outlier_factor_))

    ##Store all observations indexes, current correlation, & variable relative to number of observations to avoid over-pruning (see after)
    all_index = list(subTEST.sort_values('scoreOUT').index)  ;  tot_obs = int(len(subTEST)/3)
    oldCorr = np.corrcoef(subTEST['pred'], subTEST['BimodalVAL__genus'])[0][1]

    ##Prune while there are still observations or correlation>0.90
    while loop_IN:
        index_OUT = all_index[dex]  ;  subTEST = subTEST[~(subTEST.index.isin(index_prun))] #filter already removed observations
        #Calculate new correlation and see if it increased enough
        newCorr = np.corrcoef(subTEST[(subTEST.index!=index_OUT)]['pred'], subTEST[(subTEST.index!=index_OUT)]['BimodalVAL__genus'])[0][1]
        if (((newCorr/oldCorr)-1)>=thr_evol_corr):

            index_prun.append(index_OUT)  ;  oldCorr = newCorr
            if (len(index_prun)/tot_obs)>=count_prun: #recalculate outlier scores if too much observations pruned
                count_prun+=1
                clf = LocalOutlierFactor(n_neighbors=4, p=1).fit(-np.log(subTEST[features_iso]))
                subTEST['scoreOUT'] = np.abs(1-np.abs(clf.negative_outlier_factor_))
                all_index = list(subTEST.sort_values('scoreOUT').index)  ;  dex = 0  ;  tot_obs = int(len(subTEST)/3)
        dex+=1
        if (dex>=len(all_index))|(np.round(newCorr,2)>0.75):
            loop_IN = False
    
    
    #Second filtering for pruned data (correlation between prediction and Bimodal's value >0.75)
    loop_IN = True  ;  count_prun = 0

    ##Get relevant data and fit the LocalOutlierFactor model
    subTEST = TEST_data_pred[(TEST_data_pred['pred']>=thr_predDOWN2)&(TEST_data_pred['pred']<=thr_predUP2)&
                            ~(TEST_data_pred.index.isin(index_prun))].copy(deep=True).fillna(1)
    clf = LocalOutlierFactor(n_neighbors=5, p=1).fit(-np.log(subTEST[features_iso]))
    subTEST['scoreOUT'] = np.abs(1-np.abs(clf.negative_outlier_factor_))  ;  tot_obs = len(subTEST)
    max_pruning_round = int(np.floor(tot_obs/4))

    ##Prune until reached maximum number of pruning's turns allowed (see max_pruning_round variable)
    while loop_IN:
        subTEST = subTEST[~(subTEST.index.isin(index_prun))].sort_values('scoreOUT') #filter already removed observations

        #Calculate ratio of outlier scores for the 2 observations with minimum scores, and those with maximum
        ratio_diff = (list(subTEST['scoreOUT'])[1]/list(subTEST['scoreOUT'])[0])-1
        ratio_diffINV = (list(subTEST['scoreOUT'])[-1]/list(subTEST['scoreOUT'])[-2])-1
        ratioOUT = np.round(ratio_diffINV,2)/(np.round(ratio_diff,2))
        
        #Check if the relevant outlier is the one with minimum outlier score ...
        if (ratio_diff>ratio_diffINV)|(ratio_diffINV<1.25):
            index_OUT = list(subTEST.sort_values('scoreOUT').index)[0]
        else: #... or the one with the maximum score
            index_OUT = list(subTEST.sort_values('scoreOUT').index)[-1]
        if (ratio_diff<5e-2)&(ratioOUT<10): #In case of value too low, priotiraze maximum score
            index_OUT = list(subTEST.sort_values('scoreOUT').index)[-1]
        index_prun.append(index_OUT)
        
        if (len(subTEST)/tot_obs)<0.90: #recalculate outlier scores if enough observations pruned
            if count_prun>=max_pruning_round: #Stop pruning if reached maximum number of pruning's turns allowed
                loop_IN = False
                #Global (high n_neighbors) filtering before leaving loop
                clf = LocalOutlierFactor(n_neighbors=int(len(subTEST)/2), p=1).fit(-np.log(subTEST[features_iso]))
                subTEST['scoreOUT'] = np.abs(1-np.abs(clf.negative_outlier_factor_))
                index_prun = index_prun+list(subTEST[subTEST['scoreOUT']<np.quantile(np.round(subTEST['scoreOUT'], 3), 0.05)].index)

            else:
                clf = LocalOutlierFactor(n_neighbors=10, p=1).fit(-np.log(subTEST[features_iso]))
                subTEST['scoreOUT'] = np.abs(1-np.abs(clf.negative_outlier_factor_))  ;  count_prun+=1
    
    #Filter data probabilities according to filtering
    TEST_data_pred_filter = TEST_data_pred.copy(deep=True)
    TEST_data_pred_filter.loc[(TEST_data_pred_filter.index.isin(index_prun)), 'pred'] = TEST_data_pred_filter[
        (TEST_data_pred_filter.index.isin(index_prun))]['pred']/factor_pred_decrease
    return(TEST_data_pred_filter)

def OutlierFiltering2(TEST_data_pred, features_iso=['pred', 'BimodalVAL__family', 'BimodalVAL__genus'],
                      thr_predUP1=1e-1, thr_predDOWN1=1e-2, factor_pred_decrease=4, max_iter=10):
    """
    Filter observations by using LocalOutlierFactor for non-noised data having correlation between probabilities and expect too low (see predict_class function)

    :param TEST_data_pred: a pandas dataframe, corresponding to LF test data (see predict_class function)
    :type TEST_data_pred: pandas.core.frame.DataFrame
    :param features_iso: features used to compute outlier score (see sklearn.neighbors.LocalOutlierFactor)
    :type features_iso: list
    :param thr_predUP1: the upper limit of probability considered (see after)
    :type thr_predUP1: float
    :param thr_predDOWN1: the lower limit of probability considered (see after)
    :type thr_predDOWN1: float
    :param factor_pred_decrease: factor to decrease probabilities of identified outliers (see after)
    :type factor_pred_decrease: int
    :param max_iter: maximum number of iteration allowed (see after)
    :type max_iter: int
    
    :return: LF test data with corrected probabilities values
    :rtype: pandas.core.frame.DataFrame
    """
    
    #Get correlation prior to pruning, and outliers scores associated
    index_prun = []  ;  count_pruning = 0  ;  new_corr = 0
    old_corr = np.corrcoef(TEST_data_pred['pred'], TEST_data_pred['LOGneg_best_expect__0__genus'])[0][1]
    subTEST = TEST_data_pred[(TEST_data_pred['pred']>=thr_predDOWN1)&(TEST_data_pred['pred']<=thr_predUP1)].copy(deep=True).fillna(1)
    clf = LocalOutlierFactor(n_neighbors=int(len(subTEST)/3), p=1).fit(-np.log(subTEST[features_iso]))
    subTEST['scoreOUT'] = np.abs(1-np.abs(clf.negative_outlier_factor_))
    
    #Iter while < max_iter or correlation doesn't change
    while (np.round(new_corr,2)!=np.round(old_corr,2))&((count_pruning+1)<max_iter):
        count_pruning+=1
        for thr_score in np.arange(0,max(subTEST['scoreOUT'])+max(subTEST['scoreOUT'])/10, max(subTEST['scoreOUT'])/10):
            new_corr = np.corrcoef(subTEST[subTEST['scoreOUT']<=thr_score]['pred'], subTEST[subTEST['scoreOUT']<=thr_score]['LOGneg_best_expect__0__genus'])[0][1]
            if new_corr>old_corr:
                break
        index_prun = index_prun+list(subTEST[subTEST['scoreOUT']>=thr_score].index)
        subTEST = subTEST[~subTEST.index.isin(index_prun)]  ;  old_corr = new_corr
        clf = LocalOutlierFactor(n_neighbors=int(len(subTEST)/3), p=1).fit(-np.log(subTEST[features_iso]))
        subTEST['scoreOUT'] = np.abs(1-np.abs(clf.negative_outlier_factor_))
    
    #Filter data probabilities according to filtering
    TEST_data_pred_filter = TEST_data_pred.copy(deep=True)
    TEST_data_pred_filter.loc[(TEST_data_pred_filter.index.isin(index_prun)), 'pred'] = TEST_data_pred_filter[
        (TEST_data_pred_filter.index.isin(index_prun))]['pred']/factor_pred_decrease
    return(TEST_data_pred_filter)

def predict_class(TEST_data, path_saveRF):
    """
    Predict probability of being a true positive for each genus identified

    :param TEST_data: a pandas dataframe, corresponding to LF test data (see Create_TRAIN_TEST_data function)
    :type TEST_data: pandas.core.frame.DataFrame
    :param path_saveRF: path to the random forest model
    :type path_saveRF: str
    
    :return: a pandas dataframe, corresponding to LF test data with the probabilities associated to each observation
    :rtype: list
    """
    
    #Load model & make predictions
    RF = pickle.load(open(path_saveRF, 'rb'))  ;  TEST_data_pred = TEST_data.copy(deep=True).reset_index().drop('index', axis=1)
    missed = TEST_data_pred[TEST_data_pred.index.isin(TEST_data_pred[TEST_data_pred['Missed_Added']!=0].index)].copy(deep=True)
    TEST_data_pred = TEST_data_pred[TEST_data_pred['Missed_Added']==0].copy(deep=True)
    TEST_data_pred['pred'] = [1-i[0] for i in RF.predict_proba(TEST_data_pred[RF.feature_names_in_].fillna(0))]
    
    #Filter non-relevant predictions
    TEST_data_pred.loc[TEST_data_pred['BimodalVAL__phylum'].isna(), 'pred'] = 0
    TEST_data_pred.loc[TEST_data_pred['LOGneg_best_expect__0__genus']==0, 'pred'] = 0
    
    #In case of model trained with too much noised data (see Create_RFmodel function):
    ##-> Filter data close to class' prediction cut-off (0.5) if correlation between prediction and Bimodal's value
    ### high enough but not too high so it can be increased + at least correlation between prediction & expect value :
    flag_noise = sum([('diff_acc_spe' in feature) for feature in RF.feature_names_in_])==0
    flag_corrHigh = (np.corrcoef(TEST_data_pred['pred'], TEST_data_pred['BimodalVAL__genus'])[0][1]>0.6)&(
        np.corrcoef(TEST_data_pred['pred'], TEST_data_pred['BimodalVAL__genus'])[0][1]<0.7)
    flag_corrExpect = np.corrcoef(TEST_data_pred['pred'], TEST_data_pred['LOGneg_best_expect__0__genus'])[0][1]>0.15
    if (flag_noise&flag_corrHigh&flag_corrExpect):
        print("Model was trained on too much noised data\n\tBimodal Gaussian's correlation high enough -> applying LocalOutlierFactor correction")
        TEST_data_pred = OutlierFiltering(TEST_data_pred)
    
    #If not the case, check if correlation between pred and LOGneg_best_expect__0__genus high enough
    ## If not, need for post filtering:
    flag_corrExpect = np.corrcoef(TEST_data_pred['pred'], TEST_data_pred['LOGneg_best_expect__0__genus'])[0][1]>0.25
    if (not flag_noise)&(not flag_corrExpect):
        print("Model was trained on not too much noised data but probabilies and expect's correlation too low\n\tApplying LocalOutlierFactor correction")
        TEST_data_pred = OutlierFiltering2(TEST_data_pred)
    
    #Add missing ones
    TEST_data_pred = pd.concat([TEST_data_pred, missed]).fillna(0)
    return(TEST_data_pred)