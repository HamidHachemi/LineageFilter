import pandas as pd
import numpy as np
from tqdm import tqdm
import re


def convertUNIPEPT_mpaOUT(path_to_MPA, levels_LF=['phylum', 'class', 'order', 'family', 'genus'], sep='\t'):
    """
    Convert Unipept Metaproteomics Analysis output tsv file into LF compatible tables,
     namely specific and non-specific distribution at considered taxonomical levels (Tdistris)

    :param path_to_MPA: the path to Unipept tsv file
    :type path_to_MPA: str
    :param levels_LF: taxonomical levels considered
    :type levels_LF: list
    :param sep: separator used to separate values in file (comma for csv files, tab for tsv files, ...)
    :type sep: str
    
    :return: a list of pandas dataframe, each corresponding to a given Tdistri
    :rtype: list
    """
    
    all_tables_Quanti = []
    sample = path_to_MPA.split('_mpa.csv')[0].split('\\')[-1].split('/')[-1]  ;  print("Converting Unipept mpa - "+sample)
    
    #Read file
    try:
        MPA_table = pd.read_csv(path_to_MPA, sep=sep, index_col=False)
    except:
        print('File was badly formated, reading it line by line')
        with open(path2MPA+pval+'\\'+file.split('.txt')[0]+'_mpa.csv', 'r') as f:
            lines = [i.rstrip() for i in f.readlines()]
        rel_lines = [i.split(sep)[0:21] for i in lines]  ;  rel_lines = [i for i in rel_lines if len(i)==len(rel_lines[0])]
        MPA_table = pd.DataFrame(rel_lines[1:])  ;  MPA_table.columns = rel_lines[0]
    
    shared_peptides = {'root':len(MPA_table[['peptide', 'lca']][MPA_table['lca']=='root'])}
    for level in levels_LF:
        index_level = np.where(np.array(levels_LF)==level)[0][0]
        level_MPA = MPA_table[['peptide', 'lca', level]][~MPA_table[level].isna()]
        all_taxas = level_MPA[level].unique()  ;  MPA_save_table = pd.DataFrame()
        shared_level = level_MPA[level_MPA['lca']==level_MPA[level]].groupby(level).size()
        shared_level = dict(zip(shared_level.index, list(shared_level)))
        shared_peptides[level] = shared_level
        for t in tqdm(range(len(all_taxas))):
            Name = all_taxas[t]  ;  tmp_table = level_MPA[level_MPA[level]==Name]
            #Retrieve taxonomy
            api_out = list(pd.read_csv('https://api.unipept.ugent.be/api/v1/pept2lca.json?input[]='+list(tmp_table['peptide'])[0]+
                                       '&equate_il=true&extra=true&names=true', header=None, sep='NOsep', engine='python')[0])[0]
            Lineage = pd.DataFrame(eval(api_out.replace('null', '""')))
            if len(Lineage)>0:
                Lineage = Lineage[~Lineage[level+'_name'].isna()]  ;  TaxID = list(Lineage[level+'_id'])[0]

                spePEPS_descent = len(tmp_table)  ;  PEPS_shared = spePEPS_descent+ shared_peptides['root']
                for shared_level_sup in levels_LF[0:index_level]: #get shared peptides at superior level
                    try:
                        PEPS_shared = PEPS_shared+shared_peptides[shared_level_sup][list(Lineage[shared_level_sup+'_name'])[0]]
                    except: #no shared for up level
                        pass
                tmp_tab = pd.DataFrame({'Name':[Name], 'TaxID':[TaxID], '# spePEPS':[spePEPS_descent], '# PEPS_shared':[PEPS_shared]})
                MPA_save_table = pd.concat([MPA_save_table, tmp_tab])
        
        all_tables_Quanti.append(MPA_save_table[MPA_save_table['Name']!=''])
    return(all_tables_Quanti)

def extractEXPECT(query_peprank2expect, path_DAT, Lineage_tab, Prot2Tax, top_n=10,
                  levels_LF=['phylum', 'class', 'order', 'family', 'genus']):
    """
    Extract top_n best expects values from Mascot DAT file & dictionary of expect values,
     at considered taxonomical levels (Edistris)

    :param query_peprank2expect: dictionnary of expect values (key=(query number, peptide number), value=expect_value) => ex:{(4, 1): 0.53,...}
    :type query_peprank2expect: dict
    :param path_DAT: path to Mascot DAT file
    :type path_DAT: str
    :param Lineage_tab: pandas dataframe linking TaxID to lineage and scientific name
    :type Lineage_tab: pandas.core.frame.DataFrame
    :param Prot2Tax: pandas dataframe linking NCBInrS RefSeq accessions to TaxID
    :type Prot2Tax: pandas.core.frame.DataFrame
    :param top_n: number of top expects to take
    :type top_n: int
    :param levels_LF: taxonomical levels considered
    :type levels_LF: list
    
    :return: a list of pandas dataframe, each corresponding to a given Edistri
    :rtype: list
    """
    
    all_tables_Expect = []
    #Extract queries expect
    array_expect = np.array([np.array(['q'+str(key[0])+'_p'+str(key[1]),value], dtype=object) for key,value in query_peprank2expect.items()])
    df_expect = pd.DataFrame({'Query_Prot':array_expect[:,0], 'Expect':array_expect[:,1]})
    
    #Extract query to prot matches
    with open(path_DAT, 'r') as f:
        lines_Mascot = [i.rstrip() for i in f.readlines()]

    idx_prots_start = [i for i in range(len(lines_Mascot)) if 'Content-Type: application/x-Mascot; name="proteins"'in lines_Mascot[i]][0]
    idx_prots_end = [i for i in range(len(lines_Mascot)) if 'Content-Type: application/x-Mascot; name="query1"'in lines_Mascot[i]][0]
    all_prots = [i for i in lines_Mascot[(idx_prots_start+2):(idx_prots_end-1)]]
    prots_access = pd.Series([re.findall('"([^"]*)"', i)[0] for i in all_prots])
    
    queries_match = [i for i in lines_Mascot if re.search('q[0-9]+_p[0-9]+=', i)]
    flag_queries_kept = pd.DataFrame([i.split('=')[0] for i in queries_match])[0].isin(list(df_expect['Query_Prot'].unique()))
    queries_match_relevant = list(map(queries_match.__getitem__, list(flag_queries_kept[flag_queries_kept].index)))
    prot_match = [re.findall('"([^"]*)"', i) for i in queries_match_relevant]
    queries_val = [i.split('=')[0] for i in queries_match_relevant]
    Query_to_Prot = pd.DataFrame({'Query':queries_val, 'Protein':prot_match}).explode('Protein')
    Query_to_Prot = Query_to_Prot.merge(df_expect, left_on='Query', right_on='Query_Prot').drop('Query_Prot', axis=1)
    
    
    #Extract query to taxa matches
    MatchTAXA = Prot2Tax[Prot2Tax['accession.version'].isin(list(Query_to_Prot['Protein'].unique()))]
    Query_to_Taxa = Query_to_Prot.merge(MatchTAXA, left_on='Protein', right_on='accession.version', how='left').drop(
        ['Protein', 'accession.version'], axis=1)
    Query_to_Taxa = Query_to_Taxa[~Query_to_Taxa['taxid'].isna()]  ;  Query_to_Taxa['Query_num'] = [i.split('_')[0] for i in list(Query_to_Taxa['Query'])]
    
    #Extract query to taxa top_n matches
    Lineage_tab['TaxID'] = Lineage_tab['TaxID'].astype(int)  ;  Query_to_Taxa['taxid'] = Query_to_Taxa['taxid'].astype(int)
    LineageEXP = Query_to_Taxa.merge(Lineage_tab, left_on='taxid', right_on='TaxID', how='left')
    LineageEXP['Expect'] = LineageEXP['Expect'].astype(float)
    
    for level in levels_LF:
        #Take best expect => lowest values
        level_EXP = LineageEXP[['Expect', 'Query', level]].groupby(['Query', level])['Expect'].min().reset_index()
        level_EXP = level_EXP.groupby([level])['Expect'].nsmallest(top_n).reset_index().drop('level_1', axis=1)
        level_EXP['numExpect'] = sum(list(level_EXP.groupby([level]).apply(lambda x:list(range(len(x))))),[])
        level_EXP = level_EXP.pivot(index=level, columns='numExpect', values='Expect').fillna(1)
        level_EXP[:] = np.vectorize(lambda x:np.abs(np.log10(x)))(level_EXP)
        level_EXP = level_EXP.reset_index()  ;  level_EXP.columns = ['TaxID']+['LOGneg_best_expect__'+str(i) for i in range(top_n)]
        all_tables_Expect.append(level_EXP)
    
    return(all_tables_Expect)