import pandas as pd
import numpy as np
from scipy.integrate import quad
from sklearn.metrics import auc


def getLFdat(all_tables_Quanti, all_tables_Expect, Weight_tree, FULL_Lineage, TaxID_ChangeLOG,
             QnonSPE_colname='# PEPS_shared', QSPE_colname='# spePEPS', range_sigma=np.arange(0.01, 20.01, 0.1),
             range_pond1 = np.arange(5e-2, 0.5, 5e-2), range_pond2 = np.arange(5e-2, 0.5, 5e-2),
             levels_LF=['phylum', 'class', 'order', 'family', 'genus']):
    """
    Process quantification and expect data at each taxonomical level to get LineageFilter data,
     namely dataframe with all features used for Random Forest prediction at level genus

    :param all_tables_Quanti: a list of pandas dataframe, each corresponding to the taxa quantification (non-specific and specific) at a given taxonomical level
    :type all_tables_Quanti: list
    :param all_tables_Expect: a list of pandas dataframe, each corresponding to a given best expect at a given taxonomical level
    :type all_tables_Expect: list
    :param Weight_tree: pandas dataframe containing parameters to compute Pweight parameter
    :type Weight_tree: pandas.core.frame.DataFrame
    :param FULL_Lineage: pandas dataframe containing the full lineage of each taxon
    :type FULL_Lineage: pandas.core.frame.DataFrame
    :param TaxID_ChangeLOG: pandas dataframe containing the changelog of NCBI taxids
    :type TaxID_ChangeLOG: pandas.core.frame.DataFrame
    :param QnonSPE_colname: name of the non-specific quantification colname, default # PEPS_shared (Unipept)
    :type QnonSPE_colname: str
    :param QSPE_colname: name of the specific quantification colname, default # spePEPS (Unipept)
    :type QSPE_colname: str
    :param range_sigma: numpy array containing all the sigmas value to compute for the Laplacian Gaussian
    :type range_sigma: numpy.ndarray
    :param range_pond1: numpy array containing all the ponderation factors used for first bimodal Gaussian
    :type range_pond1: numpy.ndarray
    :param range_pond2: numpy array containing all the ponderation factors used for second bimodal Gaussian
    :type range_pond2: numpy.ndarray
    :param levels_LF: taxonomical levels considered
    :type levels_LF: list
    
    :return: a dataframe corresponding to LineageFilter features for each genus identified in sample
    :rtype: pandas.core.frame.DataFrame
    """
    
    #Merge expect and quantification data
    all_levelsDF = {}
    
    for i in range(len(levels_LF)):
        level = levels_LF[i]  ;  Quanti = all_tables_Quanti[i].copy(deep=True)  ;  Exp = all_tables_Expect[i].copy(deep=True)  ;  Quanti = Quanti[Quanti['TaxID']!='']  ;  Quanti = Quanti[Quanti[QSPE_colname]>0]
        Quanti['TaxID'] = Quanti['TaxID'].fillna(0).astype(int)  ;  Exp['TaxID'] = Exp['TaxID'].astype(int) #homogenise type just in case, for merging
        merged_at_level = Quanti.merge(Exp, left_on='TaxID', right_on='TaxID', how='left').fillna(0)

        #take into account TaxID that may have changed if different NCBI versions were used
        missing_exp= list(merged_at_level[merged_at_level['LOGneg_best_expect__0']==0]['TaxID'])
        tmpChangeLOG = TaxID_ChangeLOG[TaxID_ChangeLOG['taxid'].isin(missing_exp)]
        tmpChangeLOG = tmpChangeLOG[~tmpChangeLOG['change-value'].isna()]
        if len(tmpChangeLOG)>0:
            tmpChangeLOG['change-value'] = tmpChangeLOG['change-value'].str.split(';')  ;  tmpChangeLOG = tmpChangeLOG.explode('change-value')
            tmpChangeLOG['change-value'] = tmpChangeLOG['change-value'].astype(int)
            tmp = Quanti.merge(tmpChangeLOG[['taxid', 'change-value']], left_on='TaxID', right_on='taxid', how='left')
            Good_TaxID = Exp[Exp['TaxID'].isin(tmp[~tmp['change-value'].isna()]['change-value'].astype(int))]['TaxID']
            if len(Good_TaxID)>0:
                tmp = tmp[tmp['change-value'].isin(Good_TaxID)][['TaxID', 'change-value']]
                Quanti = Quanti.merge(tmp, left_on='TaxID', right_on='TaxID', how='left')
                Quanti.loc[~Quanti['change-value'].isna(), 'TaxID'] = Quanti[~Quanti['change-value'].isna()]['change-value']
                Quanti = Quanti.drop(['change-value'], axis=1)  ;  merged_at_level = Quanti.merge(Exp, left_on='TaxID', right_on='TaxID', how='left').fillna(0)
        all_levelsDF[level] = merged_at_level

    #Get LineageFilter dataframes (at each taxonomical level)
    all_levelsLF = {}
    for level in levels_LF:
        print('LF dataframes creation - '+level)
        levelDF = all_levelsDF[level].copy(deep=True)
        #Get NCBI Weight for each taxa (~number of prots found in database)
        tmp_weight = levelDF.merge(Weight_tree, left_on='TaxID', right_on='name', how='left')[['pond_prob_attri', 'pond_prob_prot']].fillna(0)
        levelDF['pond_prob_attri'] = tmp_weight['pond_prob_attri']  ;  levelDF['pond_prob_prot'] = tmp_weight['pond_prob_prot']
        levelDF['Pweight'] = tmp_weight['pond_prob_attri']*tmp_weight['pond_prob_prot']

        #LF Processing
        ##Compute Bad Attribution Risk
        relevantLEVELS = [level]+list(FULL_Lineage.columns)[:[i for i in range(len(list(FULL_Lineage.columns))) if list(
            FULL_Lineage.columns)[i]=='superkingdom'][0]]  ;  levelLineage = FULL_Lineage[relevantLEVELS].fillna(1)
        levelLineage[level] = levelLineage[level].astype(int)  ;  levelLineage = levelLineage[levelLineage[level]==levelLineage['0']]
        levelLineage = levelLineage[levelLineage[level].isin(list(levelDF['TaxID']))]
        all_Lineages = list(levelLineage.apply(lambda x:list(set(list(x))), axis=1))  ;  max_dist = np.max([len(set(Lin)) for Lin in all_Lineages])
        BriskDF = pd.DataFrame({'TaxID':levelLineage['0'], 'Brisk':[np.mean(sum([[len(list(set(lineageTAX).intersection(Lin)))] if Lin[0]!=lineageTAX[0] else [] for Lin in all_Lineages],[]))/max_dist for lineageTAX in all_Lineages]})
        levelDF = levelDF.merge(BriskDF, left_on='TaxID', right_on='TaxID', how='left').fillna(1)

        ##Compute minSigma
        AllSigs = pd.DataFrame(data={})
        for sigma in range_sigma:
            N = -1/((sigma**4)*np.pi)
            x = levelDF['Brisk']  ;  y = levelDF['Pweight']
            LPG = N*np.exp(-((np.square(x))+(np.square(y)))/(2*sigma**2))*(1-(((np.square(x))+(np.square(y)))/(2*sigma**2)))
            miniLPG = N*np.exp(-((np.square(0))+(np.square(0)))/(2*sigma**2))*(1-(((np.square(0))+(np.square(0)))/(2*sigma**2)))
            thrNONspe = (1-(LPG/miniLPG))*sum(levelDF[QnonSPE_colname])
            AllSigs = pd.concat([AllSigs, pd.DataFrame({'TaxID':levelDF['TaxID'], 'sigma':sigma, 'val':levelDF[QnonSPE_colname]>=thrNONspe})])
        DFminSig = AllSigs[AllSigs['val']==True].groupby('TaxID')['sigma'].nsmallest(1).reset_index().drop('level_1', axis=1)
        DFminSig.columns = ['TaxID', 'minSigma']
        levelDF = levelDF.merge(DFminSig, left_on='TaxID', right_on='TaxID', how='left').fillna(range_sigma[-1]+(range_sigma[-1]-range_sigma[-2]))

        ###Compute validation parameters (percent taxa, nonSpe and Spe quantification validated at each minSigma)
        levelDF = levelDF.sort_values('minSigma')  ;  levelDF = levelDF.reset_index().drop('index', axis=1)
        PCval = levelDF.groupby('minSigma').apply(lambda x:len(x)).reset_index()  ;  PCval.columns = ['minSigma', 'value']
        nonSPEval = levelDF.groupby('minSigma').apply(lambda x:sum(x[QnonSPE_colname])).reset_index()  ;  nonSPEval.columns = ['minSigma', 'value']
        SPEval = levelDF.groupby('minSigma').apply(lambda x:sum(x[QSPE_colname])).reset_index()  ;  SPEval.columns = ['minSigma', 'value']
        PCval['taxa_val'] = PCval['value'].cumsum()/max(PCval['value'].cumsum())
        nonSPEval['nonSPE_val'] = nonSPEval['value'].cumsum()/max(nonSPEval['value'].cumsum())
        SPEval['SPE_val'] = SPEval['value'].cumsum()/max(SPEval['value'].cumsum())

        levelDF = levelDF.merge(PCval[['minSigma','taxa_val']], left_on='minSigma', right_on='minSigma', how='left')
        levelDF = levelDF.merge(nonSPEval[['minSigma','nonSPE_val']], left_on='minSigma', right_on='minSigma', how='left')
        levelDF = levelDF.merge(SPEval[['minSigma','SPE_val']], left_on='minSigma', right_on='minSigma', how='left')

        ##Statistical analysis - H1 : Theorical distribution of FP taxa min_𝑠𝑖𝑔𝑚𝑎
        ##                       H0 : Observed distribution of min_𝑠𝑖𝑔𝑚𝑎
        def Gaussian(x, mu, sig):
            return (1/(sig*np.sqrt(2*np.pi)))*np.exp(-0.5*((x-mu)/sig)**2)
        mu_theo = max(levelDF['minSigma'])/2  ;  sig_theo = 1
        mu = np.mean(levelDF['minSigma'])  ;  sig = np.std(levelDF[levelDF['minSigma']<=mu]['minSigma'])
        theo = (1/(sig_theo*np.sqrt(2*np.pi)))*np.exp(-0.5*((levelDF['minSigma']-mu_theo)/sig_theo)**2)
        obs = (1/(sig*np.sqrt(2*np.pi)))*np.exp(-0.5*((levelDF['minSigma']-mu)/sig)**2)

        try:
            sig_cross = list(levelDF['minSigma'])[np.where([np.sign(i)!=np.sign(theo-obs)[0] for i in theo-obs])[0][0]]
        except:
            sig_cross = max(levelDF['minSigma'])
        levelDF['sig_cross'] = sig_cross

        ###Get p_value MSMS
        old_sigma = 0  ;  integ_theo = []  ;  integ_obs = []
        for sigma in set(list(levelDF['minSigma'])):
            try:
                INT_theo = quad(Gaussian, old_sigma, sigma, args=(mu_theo,sig_theo))
            except:
                INT_theo = [0]
            try:
                INT_obs = quad(Gaussian, old_sigma, sigma, args=(mu,sig))
            except:
                INT_obs = [0]
            integ_theo.append(INT_theo[0])  ;  integ_obs.append(INT_obs[0])
        AUC = pd.DataFrame(data={'min_sigma':list(set(list(levelDF['minSigma']))), 'theo':integ_theo, 'obs':integ_obs})
        levelDF['p_value_MSMS'] = list(AUC['obs'])[np.argmin(np.abs(AUC['min_sigma']-sig_cross))]

        ###Specific evolution parameters
        levelDF.index = range(len(levelDF.index))
        levelDF['acc_spe_evolve'] = levelDF[QSPE_colname].cumsum()  ;  max_acc_spe = max(levelDF['acc_spe_evolve'])
        levelDF['acc_spe_evolve'] = levelDF['acc_spe_evolve']/max_acc_spe
        levelDF['diff_acc_spe'] = np.array(list(levelDF['acc_spe_evolve']))-np.array([0]+list(levelDF['acc_spe_evolve'])[:-1])

        ###Gaussian Mixture processing -> bimodal Gaussian

        mu1 = min(levelDF['minSigma'])  ;  mu2 = (max(levelDF['minSigma'])-mu1)/3  ;  sd1 = (mu2*2)  ;  sd2 = sd1
        thr_cross = pd.DataFrame(data={'minSigma':list(levelDF['minSigma'].unique()), 'thr':mu1+0.5*sd1})
        thr_cross['diff'] = np.abs(thr_cross['minSigma']-thr_cross['thr'])
        try:
            thr_cross = float(list(thr_cross[thr_cross['diff']==min(thr_cross['diff'])]['minSigma'])[0])
        except:
            thr_cross = float(max(thr_cross['minSigma']))
        try:
            diff_over = max(levelDF['diff_acc_spe'])-max(levelDF[levelDF['diff_acc_spe']!=max(levelDF['diff_acc_spe'])]['diff_acc_spe'])
        except:
            diff_over = 1

        tmp = levelDF.copy(deep=True)[['minSigma', 'diff_acc_spe']].groupby('minSigma').apply(
            lambda x:max(x['diff_acc_spe'])).reset_index()  ;  tmp.columns = ['minSigma', 'max']
        tmp['max'] = np.round(tmp['max'],5)  ;  tmp = tmp[tmp['max']<(max(tmp['max'])/10)]
        tmp['diff'] = np.round(np.array(list(tmp['minSigma']))-np.array([0]+list(tmp['minSigma'])[:-1]), 2)
        tmp['cross'] = list(tmp['diff']==0.1)
        try:
            sigma_noise = tmp.iloc[max([i for i, x in enumerate(list(tmp['cross'])) if not x])]['minSigma']
        except:
            sigma_noise = max(tmp['minSigma'])*1.5
        if sigma_noise==max(levelDF['minSigma']):
            sigma_noise = sigma_noise*0.75
        diff_norm = diff_over/max(levelDF['diff_acc_spe'])


        levelDF['diff_norm'] = diff_norm  ;  levelDF['thr_cross'] = thr_cross  ;  levelDF['sigma_noise'] = sigma_noise
        levelDF['mu1'] = mu1  ;  levelDF['sd1'] = sd1  ;  levelDF['mu2'] = mu2  ;  levelDF['sd2'] = sd2
        levelDF['diff_over'] = diff_over  ;  levelDF['maxSPE'] = max(levelDF['diff_acc_spe'])

        comb = np.array([(x, y, int(z)) for x in range_pond1 for y in range_pond1 for z in list(levelDF['TaxID'])])
        pond1 = comb[:,0]  ;  pond2 = comb[:,1]  ;  taxa = comb[:,2]
        COMB = pd.DataFrame(data={'pond1':pond1 , 'pond2':pond2 , 'TaxID':taxa})
        COMB['TaxID'] = COMB['TaxID'].astype(int)  ;  levelDF['TaxID'] = levelDF['TaxID'].astype(int)
        try:
            OPT = levelDF.merge(COMB, left_on='TaxID', right_on='TaxID', how='left')
        except:
            OPT = levelDF.merge(COMB, left_on='TaxID', right_on='TaxID', how='left')

        OPT['fit'] = Gaussian(np.array(OPT['minSigma']), mu1, sd1)
        OPT['fit'] = np.multiply(np.array(OPT['fit']).astype(float), np.array(OPT['pond1']).astype(float))
        OPT['fit2'] = Gaussian(np.array(OPT['minSigma']), mu2, sd2)
        OPT['fit2'] = np.multiply(np.array(OPT['fit2']).astype(float), np.array(OPT['pond2']).astype(float))
        OPT.loc[OPT['minSigma'] > thr_cross, 'fit'] = 0
        OPT.loc[OPT['minSigma'] < thr_cross, 'fit2'] = 0
        OPT['distri_theo'] = np.array(OPT['fit'])+np.array(OPT['fit2'])
        OPT.loc[OPT['minSigma'] == thr_cross, 'distri_theo'] = np.array(OPT.loc[OPT['minSigma'] == thr_cross, 'distri_theo'])/2
        OPT.columns = [sub +'__'+level for sub in OPT.columns]
        
        bimodal_summ =  OPT.groupby('TaxID__'+level).apply(lambda x:auc(sorted(list(x['distri_theo__'+level].unique())),[
            max(x['diff_acc_spe__'+level])]*len(x['distri_theo__'+level].unique()))).reset_index().sort_values(0)
        bimodal_summ.columns = ['TaxID__'+level, 'BimodalVAL__'+level]
        OPT = OPT.merge(bimodal_summ, left_on='TaxID__'+level, right_on='TaxID__'+level, how='left').drop([
            'pond1__'+level, 'pond2__'+level, 'fit__'+level, 'fit2__'+level, 'distri_theo__'+level], axis=1).drop_duplicates()
        all_levelsLF[level] = OPT


    #Merge LineageFilter dataframes to create LFdat dataframe
    LF_dat = all_levelsLF['genus'].copy(deep=True)
    tmp_lineage = FULL_Lineage[FULL_Lineage['genus'].isin(list(LF_dat['TaxID__genus']))][levels_LF].drop_duplicates()
    tmp_lineage['genus'] = tmp_lineage['genus'].astype(int)
    LF_dat = LF_dat.merge(tmp_lineage, left_on='TaxID__genus', right_on='genus', how='left')
    for sup_level in levels_LF[::-1][1:]:
        sup_dat = all_levelsLF[sup_level].copy(deep=True)
        LF_dat[sup_level] = LF_dat[sup_level].fillna(0).astype(int)
        sup_dat['TaxID__'+sup_level] = sup_dat['TaxID__'+sup_level].fillna(0).astype(int)
        LF_dat = LF_dat.merge(sup_dat, left_on=sup_level, right_on='TaxID__'+sup_level, how='left')
    
    #Add missing TaxID (In case there were missing ones) 
    missingQuanti = all_tables_Quanti[-1][~(all_tables_Quanti[-1]['TaxID'].isin(LF_dat['TaxID__genus']))][['TaxID', QnonSPE_colname, QSPE_colname]]
    missingQuanti.columns = ['TaxID__genus', QnonSPE_colname+'__genus', QSPE_colname+'__genus']
    tmp_change = TaxID_ChangeLOG[TaxID_ChangeLOG['taxid'].fillna(-1).astype(int).isin(missingQuanti['TaxID__genus'])].copy(deep=True)
    tmp_change['change-value'] = tmp_change['change-value'].fillna(-1).astype(str).str.split(';')  ;  tmp_change = tmp_change.explode('change-value')
    already_taken_into_account = tmp_change[tmp_change['change-value'].fillna(-1).astype(int).isin(LF_dat['TaxID__genus'])]['taxid']
    missingQuanti = missingQuanti[~missingQuanti['TaxID__genus'].isin(already_taken_into_account)]
    LF_dat['Missed_Added'] = 0  ;  missingQuanti['Missed_Added'] = 1  ;  LF_dat = pd.concat([LF_dat, missingQuanti])
    
    return(LF_dat)